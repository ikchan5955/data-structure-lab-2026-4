import sys

sys.stdin = open('case.txt')
N, M = list(map(int,input().split()))
print(N, M)
concerts = []
for v in range(N):
    values = list(map(int, input().split()))
    concerts.append(values)
# print(concerts)
# [[1, 0, 0, 1, 1, 0], [1, 0, 1, 1, 0, 0], [1, 1, 1, 1, 0, 1], [0, 1, 1, 0, 1, 1], [0, 1, 0, 0, 1, 0]]
################################################

def count_stages(concerts):
    """
    [독립된 무대 공간 산출 설계 및 동작 설명]
    주어진 2차원 배열 약도에서 상하좌우로 연결된 '0'(빈 공간)들의 군집 개수를 세는 방식입니다.
    파이썬에서 재귀를 이용한 DFS는 깊이 제한 문제(RecursionError)가 발생할 우려가 있어,
    반복문과 큐(Queue)를 활용한 BFS 방식을 채택해 탐색의 안정성을 높였습니다.

    동작 로직:
    1. 방문 여부를 체크하기 위해 원본 약도와 동일한 크기의 2차원 리스트(visited)를 생성합니다.
    2. 배열 전체를 순회하며 아직 방문하지 않은 무대 공간(0)을 발견하면 정답(answer)을 1 올립니다.
    3. 해당 위치에서 BFS 알고리즘을 시작해 상, 하, 좌, 우로 연결된 모든 '0'을 탐색하고 방문(True) 처리합니다.
    """
    answer = 0
    if not concerts:
        return answer
        
    visited = [[False] * M for _ in range(N)]
    
    dx = [-1, 1, 0, 0]
    dy = [0, 0, -1, 1]
    
    for i in range(N):
        for j in range(M):
            if concerts[i][j] == 0 and not visited[i][j]:
                answer += 1 
                
                queue = [(i, j)]
                visited[i][j] = True
                
                while queue:
                    x, y = queue.pop(0)
                    
                    for k in range(4):
                        nx = x + dx[k]
                        ny = y + dy[k]
                        
                        if 0 <= nx < N and 0 <= ny < M:
                            if concerts[nx][ny] == 0 and not visited[nx][ny]:
                                visited[nx][ny] = True
                                queue.append((nx, ny))
                                
    return answer

print(count_stages(concerts))