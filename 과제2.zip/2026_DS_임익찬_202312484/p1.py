A = {
    0: [1, 2, 3],
    1: [0, 2, 4, 5],
    2: [0, 1, 6],
    3: [0],
    4: [1],
    5: [1],
    6: [2]
}

def bfs(A):
    """
    [BFS 설계 및 동작 설명]
    너비 우선 탐색(BFS)을 구현하기 위해 큐(Queue) 자료구조를 활용했습니다.
    문제 조건에서 '같은 레벨의 깊이일 경우 더 빠른 번호의 노드부터 방문'해야 하므로,
    현재 노드의 인접 노드들을 가져올 때 오름차순(sorted)으로 정렬한 뒤 큐에 삽입했습니다.
    또한 무한 루프나 중복 방문을 막기 위해 큐에 들어간 노드를 기록하는 pushed 리스트를 두었습니다.
    """
    answer = []
    queue = [0]
    pushed = [0]
    
    while queue:
        node = queue.pop(0)
        answer.append(node)
        
        for neighbor in sorted(A[node]):
            if neighbor not in pushed:
                pushed.append(neighbor)
                queue.append(neighbor)
                
    return answer

def dfs(A):
    """
    [DFS 설계 및 동작 설명]
    깊이 우선 탐색(DFS)을 구현하기 위해 스택(Stack) 자료구조를 활용했습니다.
    번호가 작은 노드부터 먼저 탐색해야 하는데 스택은 후입선출(LIFO) 구조이므로,
    인접 노드들을 내림차순(reverse=True)으로 정렬하여 스택에 삽입했습니다.
    
    특히 제공된 테스트케이스의 순서([0,1,4,5,2,6,3])를 정확히 맞추기 위해,
    스택에서 노드를 꺼낼 때가 아닌 스택에 넣을 때 방문 처리(pushed)를 하도록 로직을 짜서
    의도치 않은 노드 중복 진입을 방지했습니다.
    """
    answer = []
    stack = [0]
    pushed = [0]
    
    while stack:
        node = stack.pop()
        answer.append(node)
        
        for neighbor in sorted(A[node], reverse=True):
            if neighbor not in pushed:
                pushed.append(neighbor)
                stack.append(neighbor)
                
    return answer

bfs_result = bfs(A)
dfs_result = dfs(A)

assert bfs_result == [0,1,2,3,4,5,6]
assert dfs_result == [0,1,4,5,2,6,3]
print('PASSED!')